*PADS-LIBRARY-PART-TYPES-V9*

50SVPK120M 16SVF1000M I CAP 7 1 0 0 0
TIMESTAMP 2026.06.01.22.39.58
"TME Electronic Components Part Number" 
"TME Electronic Components Price/Stock" 
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" 50SVPK120M
"Description" Aluminum Organic Polymer Capacitors 120uf 50volts OS-CON Polymer
"Datasheet Link" http://industrial.panasonic.com/cdbs/www-data/pdf/AAB8000/AAB8000C226.pdf
"Geometry.Height" 12.7mm
GATE 1 2 0
50SVPK120M
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
719187/1640540/2.50/2/2/Capacitor Polarised
